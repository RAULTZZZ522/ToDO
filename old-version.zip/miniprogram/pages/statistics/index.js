Page({
  data: {
    todayCompleted: 3,
    weekFocus: '5小时',
    totalCompleted: 42
  }
}) 