Page({
  data: {
    aims: [
      {
        _id: '1',
        name: '学习计划',
        description: '提升自我',
        todos: [
          { _id: 't1', content: '背单词' },
          { _id: 't2', content: '刷题' }
        ]
      },
      {
        _id: '2',
        name: '健身目标',
        description: '保持健康',
        todos: [
          { _id: 't3', content: '跑步' }
        ]
      }
    ]
  }
}) 